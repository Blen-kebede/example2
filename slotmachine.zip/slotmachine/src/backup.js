const makeRoll = () => {
    let cssStr = [];

    let num = Number(roll) || 0;
    let newRoll = (num = 0 - getRotation(num));

    cssStr.push(
        "@keyframes ringAnimation" +
            id +
            "_" +
            timeRun +
            " { 0% { transform: rotateX(" +
            lastRoll +
            "deg); } 100% { transform: rotateX(" +
            num +
            "deg) }}"
    );

    window.setTimeout(() => {
        setSelf({
            style: {
                ...defaultAnimationStuff,
                animationName: "ringAnimation" + id + "_" + (timeRun - 1),
                animationDuration: 5 + Math.random() * 0.9 + "s",
            },
        });
    }, Math.random() * 100);

    setTimeRun((timeRun) => timeRun++);
    setLastRoll(newRoll);
    setRotationStyle((rotationStyle) => cssStr.join(""));
    setStyle({
        transform: "rotateX(" + lastRoll + "deg)",
    });
};
