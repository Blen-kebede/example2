import React from "react";
import config from "../config.json";

export default function Face({ value, won, index }) {
    const getRotation = () => {
        return (360 / config.FACES_PER_RING) * index;
    };

    let transform =
        "rotateX(" + getRotation() + "deg) translateZ(" + 20 + "vh)";

    return (
        <div
            className={"face " + (won ? "won" : "") + " bg" + value}
            style={{ transform }}
        />
    );
}
