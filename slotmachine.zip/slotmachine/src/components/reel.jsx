import React, { useState, useEffect } from "react";
import Face from "./face";
import config from "../config.json";

const defaultAnimationStuff = {
    animationDuration: "5.5s",
    animationIterationCount: "1",
    animationFillMode: "forwards",
    animationTimingFunction: "cubic-bezier(.32,.19,0,1)",
};

export default function Reels({ spinNum, roll, id, won }) {
    const [lastRoll, setLastRoll] = useState(0);
    const [timeRun, setTimeRun] = useState(0);
    const [style, setStyle] = useState({});
    const [rotationStyle, setRotationStyle] = useState("");
    const [self, setSelf] = useState({});

    useEffect(() => {
        makeRoll();
    }, [spinNum]);
    const getRotation = (num) => {
        return (360 / config.FACES_PER_RING) * num;
    };

    const makeRoll = () => {
        var cssStr = [];

        var num = Number(roll) || 0;
        let newRoll = (num = 0 - getRotation(num));
        num -= 5 * 360;

        cssStr.push(
            "@keyframes ringAnimation" +
                id +
                "_" +
                timeRun +
                " { 0% { transform: rotateX(" +
                lastRoll +
                "deg); } 100% { transform: rotateX(" +
                num +
                "deg) }}"
        );

        window.setTimeout(() => {
            setSelf({
                style: {
                    ...defaultAnimationStuff,
                    animationName: "ringAnimation" + id + "_" + (timeRun - 1),
                    animationDuration: 5 + Math.random() * 0.9 + "s",
                },
            });
        }, Math.random() * 100);

        setTimeRun((timeRun) => timeRun++);

        setTimeRun((timeRun) => timeRun++);
        setLastRoll(newRoll);
        setRotationStyle((rotationStyle) => cssStr.join(""));
        setStyle({
            transform: "rotateX(" + lastRoll + "deg)",
        });
    };
    let faces = [];
    for (let i = 0; i < config.FACES_PER_RING; i++) {
        faces.push(
            <Face
                index={i}
                key={i}
                value={config.REEL_SETUP[id][i]}
                won={won[i]}
            />
        );
    }

    return (
        <div className="ring" style={style}>
            <style dangerouslySetInnerHTML={{ __html: rotationStyle }} />
            {faces}
        </div>
    );
}
