//React Core and Hooks
import { useState, useCallback } from "react";
import useSound from "use-sound";

//Components
import Reel from "./components/reel";
import config from "./config.json";

//Style
import "./style.css";

import spinSound from "./assets/spin.mp3";
import winSound from "./assets/spinWin.mp3";
import winGif from "./assets/won.gif";

export default function App() {
    const [r1, setR1] = useState(0);
    const [r2, setR2] = useState(0);
    const [r3, setR3] = useState(0);
    const [r4, setR4] = useState(0);
    const [spinNum, setSpinNum] = useState(0);
    const [wonReels, setWonReels] = useState([]);
    const [credits, setCredits] = useState(1000);
    const [bet, setBet] = useState(1);
    const [cantSpin, setCantSpin] = useState(false);
    const [won, setWon] = useState(false);
    const [playWinSound] = useSound(winSound);
    const [playSpinSound] = useSound(spinSound);
    const [spinToggle, setSpinToggle] = useState(true);

    const changeBet = useCallback(() => {
        if (cantSpin) return;

        if (bet >= 5) setBet(1);
        else setBet((bet) => bet + 1);
    }, [cantSpin, bet]);

    const betMax = () => {
        if (cantSpin) return;
        else setBet((bet) => 5);
    };

    const onSpin = () => {
        if (cantSpin) return;
        else setSpinNum((spinNum) => spinNum + 1);
        setCredits(credits - bet);
        const getRandom = () => {
            return Math.floor(Math.random() * config.FACES_PER_RING);
        };
        setR1((r1) => getRandom());
        setR2((r2) => getRandom());
        setR3((r3) => getRandom());
        setR4((r4) => getRandom());
        setCantSpin((cantSpin) => true);
        playSpinSound();
        checkWinning();

        setTimeout(() => {
            return setCantSpin((cantSpin) => false);
        }, 6000);
    };

    const checkWinning = () => {
        if (r1 === r2 && r1 === r3 && r1 === r4) {
            playWinSound();
            setCredits(credits + bet);
        } else {
            return;
        }
    };
    return (
        <div>
            {won && <div className="wonOverlay" />}
            <div id="outer">
                <div id="stage">
                    <Reel
                        roll={r1}
                        id="1"
                        spinNum={spinNum}
                        won={wonReels[1] || {}}
                    />
                    <Reel
                        roll={r2}
                        id="2"
                        spinNum={spinNum}
                        won={wonReels[2] || {}}
                    />
                    <Reel
                        roll={r3}
                        id="3"
                        spinNum={spinNum}
                        won={wonReels[3] || {}}
                    />
                    <Reel
                        roll={r4}
                        id="4"
                        spinNum={spinNum}
                        won={wonReels[4] || {}}
                    />
                </div>
            </div>
            <div>
                <div className="infoLabels">
                    <div className="block">
                        <div className="label">Credits:</div>
                        <div className="info">{credits}</div>
                    </div>
                    <div className="block">
                        <div className="label">Stake:</div>
                        <div className="info">{bet}</div>
                    </div>
                </div>
                <span
                    className={"btnSpin " + (cantSpin ? "inactive" : "")}
                    onTouchStart={onSpin}
                    onClick={onSpin}
                >
                    SPIN
                </span>
                <span className="betButtons">
                    <span
                        className={"btnBet " + (cantSpin ? "inactive" : "")}
                        onTouchStart={changeBet}
                        onClick={changeBet}
                    >
                        BET
                    </span>
                    <br />
                    <span
                        className={"btnBet " + (cantSpin ? "inactive" : "")}
                        onTouchStart={betMax}
                        onClick={betMax}
                    >
                        MAX
                    </span>
                </span>
            </div>
        </div>
    );
}
