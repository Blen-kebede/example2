﻿# How to run "slotmachine"

Slot machine was made with "create-react-app" so running the command "npm start on the terminal will start it.


# Changes made

* The previous code was written without create-react-app so it didn't have a start script
* It was also written with class components and now uses functional components 
* a lot of the dependencies were currently deprecated so it had to be updated 
## Challenges faced and lessons learned

* I am not at all used to working with class components or webpack so I had to learn and read the React documentation to understand a lot of things
* Trying to understand another person's code to know what is happening was a challenge

## If I had more time 

I would have maybe used a library for the CSS and used a different hook for the sound effect. 


